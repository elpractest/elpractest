import { n as createComponent, r as __exportAll, t as $$Layout } from "./Layout_DzppV3bk.mjs";
import { l as renderTemplate, p as maybeRenderHead, r as renderComponent } from "./server_BmHvQwWi.mjs";
//#region src/pages/terms.astro
var terms_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Terms,
	file: () => $$file,
	url: () => $$url
});
var $$Terms = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": "Terms of Service — e-Learning Practest",
		"description": "Terms of Service and conditions of use for e-Learning Practest (Vinstitution / VPD Vastus Ventures Pvt. Ltd.).",
		"data-astro-cid-zcf6dkqz": true
	}, { "default": ($$result) => renderTemplate`${maybeRenderHead($$result)}<section class="legal-hero" data-astro-cid-zcf6dkqz><div class="legal-container" data-astro-cid-zcf6dkqz><span class="badge" data-astro-cid-zcf6dkqz>Legal & Compliance</span><h1 data-astro-cid-zcf6dkqz>Terms of Service</h1><p class="subtitle" data-astro-cid-zcf6dkqz>Last updated: July 2026</p></div></section><section class="legal-content" data-astro-cid-zcf6dkqz><div class="legal-container card" data-astro-cid-zcf6dkqz><h2 data-astro-cid-zcf6dkqz>1. Acceptance of Terms</h2><p data-astro-cid-zcf6dkqz>By accessing <code data-astro-cid-zcf6dkqz>practest.live</code>, logging in to <code data-astro-cid-zcf6dkqz>app.practest.live</code>, or enrolling in any test series or course offered by e-Learning Practest (a brand of Vinstitution / VPD Vastus Ventures Private Limited), you agree to be bound by these Terms of Service.</p><h2 data-astro-cid-zcf6dkqz>2. Account Security & Verification</h2><p data-astro-cid-zcf6dkqz>Students must provide accurate email and phone contact details during account creation. Email verification and mobile OTP verification are mandatory for course activation. Accounts are strictly personal; sharing login credentials or simultaneous test session access from multiple devices is prohibited and may lead to account suspension.</p><h2 data-astro-cid-zcf6dkqz>3. Test Series Engine & Fair Usage</h2><ul data-astro-cid-zcf6dkqz><li data-astro-cid-zcf6dkqz>Test timers are server-authoritative and will automatically submit when duration expires.</li><li data-astro-cid-zcf6dkqz>Attempting to bypass CBT lockouts, manipulate client timing scripts, or scrape question bank content via automated tools is grounds for immediate termination of access without refund.</li><li data-astro-cid-zcf6dkqz>Questions and explanations provided in the test series are intellectual property protected by copyright laws.</li></ul><h2 data-astro-cid-zcf6dkqz>4. Course Activations & Access Limits</h2><p data-astro-cid-zcf6dkqz>Course enrollments activated via issued activation codes or approved payment proof grant non-transferable access for the validity period specified in the batch parameters.</p><h2 data-astro-cid-zcf6dkqz>5. Intellectual Property</h2><p data-astro-cid-zcf6dkqz>All content, including question banks, test interface designs, video lesson content, branding assets, and software code, are owned by VPD Vastus Ventures Private Limited. Unapproved reproduction or redistribution is strictly prohibited.</p><h2 data-astro-cid-zcf6dkqz>6. Governing Law</h2><p data-astro-cid-zcf6dkqz>These Terms shall be governed by and construed in accordance with the laws of India. Any disputes arising out of or in connection with these Terms shall be subject to the exclusive jurisdiction of the courts located in New Delhi, India.</p></div></section>` })}`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/terms.astro", void 0);
var $$file = "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/terms.astro";
var $$url = "/terms";
//#endregion
//#region \0virtual:astro:page:src/pages/terms@_@astro
var page = () => terms_exports;
//#endregion
export { page };
