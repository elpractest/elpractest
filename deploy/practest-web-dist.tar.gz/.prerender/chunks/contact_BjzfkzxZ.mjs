import { n as createComponent, r as __exportAll, t as $$Layout } from "./Layout_DzppV3bk.mjs";
import { g as defineScriptVars, l as renderTemplate, p as maybeRenderHead, r as renderComponent } from "./server_BmHvQwWi.mjs";
//#region src/pages/contact.astro
var contact_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Contact,
	file: () => $$file,
	url: () => $$url
});
var $$Contact = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": "Contact — e-Learning Practest Support",
		"description": "Contact e-Learning Practest, a Vinstitution brand. Registered office in Connaught Place, New Delhi. Questions about courses, mock schedules or batch activation — reach our support team.",
		"data-astro-cid-6bfsojfh": true
	}, { "default": ($$result2) => renderTemplate`${maybeRenderHead($$result2)}<div class="contact-page-container" data-astro-cid-6bfsojfh><div class="contact-header" data-astro-cid-6bfsojfh><span class="section-label" data-astro-cid-6bfsojfh><span class="idx" data-astro-cid-6bfsojfh>✳</span> Contact us</span><h1 data-astro-cid-6bfsojfh>Get in touch</h1><p data-astro-cid-6bfsojfh>Questions about courses, mock-test schedules or batch activation? Reach the <strong data-astro-cid-6bfsojfh>e-Learning Practest<sup class="r" data-astro-cid-6bfsojfh>®</sup></strong> support team — we're happy to help.</p></div><div class="contact-content-grid" data-astro-cid-6bfsojfh><!-- Contact Details Panel --><div class="glass-panel info-panel" data-astro-cid-6bfsojfh><h3 data-astro-cid-6bfsojfh>Contact Channels</h3><div class="info-items" data-astro-cid-6bfsojfh><div class="info-item" data-astro-cid-6bfsojfh><span class="info-icon" data-astro-cid-6bfsojfh>📧</span><div data-astro-cid-6bfsojfh><span class="info-label" data-astro-cid-6bfsojfh>Email Support</span><span class="info-value" id="contact-email" data-astro-cid-6bfsojfh>support@practest.live</span></div></div><div class="info-item" data-astro-cid-6bfsojfh><span class="info-icon" data-astro-cid-6bfsojfh>📞</span><div data-astro-cid-6bfsojfh><span class="info-label" data-astro-cid-6bfsojfh>Phone Support</span><a class="info-value" id="contact-phone" href="tel:+919310959596" data-astro-cid-6bfsojfh>+91 93109 59596</a></div></div><div class="info-item" data-astro-cid-6bfsojfh><span class="info-icon" data-astro-cid-6bfsojfh>🏢</span><div data-astro-cid-6bfsojfh><span class="info-label" data-astro-cid-6bfsojfh>Registered Office</span><span class="info-value" id="contact-address" data-astro-cid-6bfsojfh>Vinstitution, 2nd Floor, Property No. 44,<br data-astro-cid-6bfsojfh>Regal Building, Connaught Place,<br data-astro-cid-6bfsojfh>New Delhi — 110090</span></div></div></div></div><!-- Contact Form Panel --><div class="glass-panel form-panel" data-astro-cid-6bfsojfh><h3 data-astro-cid-6bfsojfh>Send a Message</h3><div id="alert-box" class="alert-box" style="display: none;" data-astro-cid-6bfsojfh></div><form id="contact-form" data-astro-cid-6bfsojfh><div class="form-group" data-astro-cid-6bfsojfh><label for="name" data-astro-cid-6bfsojfh>Your Name</label><input type="text" id="name" name="name" class="form-input" placeholder="John Doe" required data-astro-cid-6bfsojfh></div><div class="form-group" data-astro-cid-6bfsojfh><label for="email" data-astro-cid-6bfsojfh>Email Address</label><input type="email" id="email" name="email" class="form-input" placeholder="john@example.com" required data-astro-cid-6bfsojfh></div><div class="form-group" data-astro-cid-6bfsojfh><label for="phone" data-astro-cid-6bfsojfh>Phone Number (Optional)</label><input type="tel" id="phone" name="phone" class="form-input" placeholder="9876543210" data-astro-cid-6bfsojfh></div><div class="form-group" data-astro-cid-6bfsojfh><label for="message" data-astro-cid-6bfsojfh>Your Message</label><textarea id="message" name="message" class="form-input" rows="5" placeholder="Write your message here..." required data-astro-cid-6bfsojfh></textarea></div><button type="submit" id="submit-btn" class="btn-primary" style="width: 100%; margin-top: 10px;" data-astro-cid-6bfsojfh>Send Message</button></form></div></div></div>` })}<script>(function(){${defineScriptVars({ apiUrl: "https://api.practest.live" })}
  // Fetch public settings to render real contact details
  async function loadContactInfo() {
    try {
      const res = await fetch(\`\${apiUrl}/api/settings/public\`);
      if (res.ok) {
        const settings = await res.json();
        
        const email = settings.contact_email || settings.support_email;
        const phone = settings.contact_phone;
        const address = settings.contact_address;

        if (email) document.getElementById('contact-email').textContent = email;
        if (phone) document.getElementById('contact-phone').textContent = phone;
        if (address) document.getElementById('contact-address').textContent = address;
      }
    } catch (e) {
      console.error('Failed to load contact info settings', e);
    }
  }

  // Handle Form Submission
  const form = document.getElementById('contact-form');
  const alertBox = document.getElementById('alert-box');
  const submitBtn = document.getElementById('submit-btn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    alertBox.style.display = 'none';
    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending...';

    const payload = {
      name: document.getElementById('name').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value || null,
      message: document.getElementById('message').value,
      recaptcha_token: 'dummy_token' // Development-friendly recaptcha bypass
    };

    try {
      const response = await fetch(\`\${apiUrl}/api/contact\`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();

      if (response.status === 201) {
        alertBox.className = 'alert-box alert-success';
        alertBox.textContent = data.message || 'Thank you! Your message has been sent successfully.';
        alertBox.style.display = 'block';
        
        // Push Lead event to GTM dataLayer
        window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
          event: 'Lead',
          contact_email: payload.email,
          contact_name: payload.name
        });

        form.reset();
      } else {
        alertBox.className = 'alert-box alert-error';
        alertBox.textContent = data.message || 'Failed to send message. Please try again.';
        alertBox.style.display = 'block';
      }
    } catch (error) {
      alertBox.className = 'alert-box alert-error';
      alertBox.textContent = 'A network error occurred. Please try again later.';
      alertBox.style.display = 'block';
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Send Message';
    }
  });

  // Execute on load
  loadContactInfo();
})();<\/script>`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/contact.astro", void 0);
var $$file = "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/contact.astro";
var $$url = "/contact";
//#endregion
//#region \0virtual:astro:page:src/pages/contact@_@astro
var page = () => contact_exports;
//#endregion
export { page };
