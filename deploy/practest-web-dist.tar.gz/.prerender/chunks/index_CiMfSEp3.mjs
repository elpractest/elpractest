import { n as createComponent, r as __exportAll, t as $$Layout } from "./Layout_DzppV3bk.mjs";
import { b as unescapeHTML, g as defineScriptVars, h as addAttribute, l as renderTemplate, p as maybeRenderHead, r as renderComponent } from "./server_BmHvQwWi.mjs";
//#region src/components/CourseCarousel.astro
var $$CourseCarousel = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${maybeRenderHead($$result)}<div class="carousel-section"><div class="carousel-header"><div><span class="section-label"><span class="idx">LIVE</span> Current batches</span><h2>Enrolling now.</h2></div><div class="carousel-nav"><button id="carousel-prev" aria-label="Previous course">←</button><button id="carousel-next" aria-label="Next course">→</button></div></div><div id="carousel-loading" class="carousel-state"><div class="omr-strip" aria-hidden="true"><i class="filled"></i><i></i><i class="filled"></i><i></i></div><p>Loading course catalog…</p></div><div id="carousel-empty" class="carousel-state" style="display: none;"><p>New batches are being scheduled — check back soon or <a href="/contact" style="color: var(--accent-color); font-weight: 650;">ask us directly</a>.</p></div><div id="carousel-track" class="carousel-track" style="display: none;"></div></div><script>(function(){${defineScriptVars({ apiUrl: "https://api.practest.live" })}
  const track = document.getElementById('carousel-track');
  const loading = document.getElementById('carousel-loading');
  const empty = document.getElementById('carousel-empty');
  const prevBtn = document.getElementById('carousel-prev');
  const nextBtn = document.getElementById('carousel-next');

  async function fetchCatalog() {
    try {
      const res = await fetch(\`\${apiUrl}/api/courses/public\`);
      if (!res.ok) throw new Error('API failed');
      const courses = await res.json();

      if (courses.length === 0) {
        loading.style.display = 'none';
        empty.style.display = 'flex';
        return;
      }
      renderCarousel(courses);
    } catch (e) {
      console.error('Failed to load carousel catalog', e);
      loading.style.display = 'none';
      empty.style.display = 'flex';
      empty.innerHTML = '<p>Could not load the course catalog right now. Please try again shortly.</p>';
    }
  }

  function renderCarousel(courses) {
    track.innerHTML = courses.map(course => {
      const activePrices = (course.batches || []).map(b => b.price_paise).filter(p => p !== null && p !== undefined);
      const minPrice = activePrices.length > 0 ? Math.min(...activePrices) / 100 : null;
      const priceText = minPrice !== null ? \`₹\${minPrice.toLocaleString('en-IN')}\` : 'Pricing soon';
      const batchName = (course.batches && course.batches[0]) ? course.batches[0].name : 'Batch TBA';

      return \`
        <a href="/courses/\${course.slug}" class="cc-card glass-panel glass-panel-hover">
          <span class="cc-top">
            <span class="cc-code">\${escapeHtml((course.exam_category || 'EXAM').toUpperCase())}</span>
            <span class="cc-mode">\${escapeHtml(course.mode || '')}</span>
          </span>
          <span class="cc-title">\${escapeHtml(course.title)}</span>
          <span class="cc-desc">\${escapeHtml(course.short_description || course.description || '')}</span>
          <span class="cc-batch">\${escapeHtml(batchName)}</span>
          <span class="cc-foot">
            <span class="cc-price">\${priceText}<em>/ batch</em></span>
            <span class="cc-cta">View details →</span>
          </span>
        </a>
      \`;
    }).join('');

    loading.style.display = 'none';
    track.style.display = 'flex';
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  if (prevBtn && nextBtn && track) {
    prevBtn.addEventListener('click', () => {
      const itemWidth = track.querySelector('.cc-card')?.offsetWidth || 320;
      track.scrollBy({ left: -(itemWidth + 20), behavior: 'smooth' });
    });
    nextBtn.addEventListener('click', () => {
      const itemWidth = track.querySelector('.cc-card')?.offsetWidth || 320;
      track.scrollBy({ left: itemWidth + 20, behavior: 'smooth' });
    });
  }

  fetchCatalog();
})();<\/script><!-- is:global — cards are injected by JS, so Astro's scoping can't reach them -->`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/components/CourseCarousel.astro", void 0);
//#endregion
//#region src/pages/index.astro
var pages_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Index,
	file: () => $$file,
	url: () => ""
});
var $$Index = createComponent(($$result, $$props, $$slots) => {
	const spaUrl = "https://app.practest.live";
	const examTracks = [
		{
			code: "SSC-CGL",
			title: "SSC CGL & CHSL",
			subjects: "Quant · Reasoning · English · GA",
			note: "Tier I & Tier II patterns"
		},
		{
			code: "BANK-PO",
			title: "Banking — SBI · IBPS",
			subjects: "Quant · Reasoning · English",
			note: "Prelims & Mains, sectional locks"
		},
		{
			code: "RRB-NTPC",
			title: "Railways RRB",
			subjects: "Maths · GI & Reasoning · GA",
			note: "NTPC · Group D CBT patterns"
		},
		{
			code: "UPSC-CSE",
			title: "UPSC Prelims",
			subjects: "GS Paper I · CSAT",
			note: "Negative-marking accurate"
		},
		{
			code: "ST-PCS",
			title: "State PCS",
			subjects: "GS · CSAT · State GK",
			note: "State-wise patterns"
		}
	];
	const faqs = [
		{
			q: "Is e-Learning Practest free to start?",
			a: "Creating an account is free. Mock test batches unlock either with an activation code issued by your coaching institute or by paying online when enrolment is open. Free-preview lessons are available on enrolled courses."
		},
		{
			q: "How do activation codes work?",
			a: "After registering and verifying your email and mobile number, request activation for your batch (or enter the 8-character code your institute gave you). The moment a code is redeemed, your course, mock tests and video lessons unlock instantly."
		},
		{
			q: "Are the mock tests exam-pattern accurate?",
			a: "Yes — sections with their own time locks, the exact five-state question palette (answered, not answered, marked, answered & marked, not visited), negative marking, and a server-side timer that keeps counting even if your device clock is wrong."
		},
		{
			q: "What happens if my internet drops mid-test?",
			a: "Every answer autosaves within seconds of selection. If your connection drops or the browser crashes, log back in and resume the attempt exactly where you left off — palette state, marked questions and the remaining time are all restored from the server."
		},
		{
			q: "Can I prepare on my phone?",
			a: "Yes. Lessons, analytics and mock tests all work on mobile. For full-length mocks we recommend a laptop or desktop to mirror the real exam-hall experience, but the palette and timer stay fully usable on a phone."
		}
	];
	const faqSchema = JSON.stringify({
		"@context": "https://schema.org",
		"@type": "FAQPage",
		"mainEntity": faqs.map((f) => ({
			"@type": "Question",
			"name": f.q,
			"acceptedAnswer": {
				"@type": "Answer",
				"text": f.a
			}
		}))
	});
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": "e-Learning Practest — Exam-Pattern Mock Tests for SSC, Banking, RRB, UPSC & State PCS",
		"data-astro-cid-lcdefpme": true
	}, { "default": ($$result2) => renderTemplate`<script type="application/ld+json">${unescapeHTML(faqSchema)}<\/script>${maybeRenderHead($$result2)}<section class="hero" data-astro-cid-lcdefpme><div class="hero-grid" data-astro-cid-lcdefpme><div class="hero-copy" data-astro-cid-lcdefpme><span class="section-label" data-astro-cid-lcdefpme><span class="idx" data-astro-cid-lcdefpme>✳</span> Govt-exam preparation, done properly</span><h1 class="hero-heading" data-astro-cid-lcdefpme><span class="red-dot-bg" data-astro-cid-lcdefpme></span>Practise like it's the <span class="marker-underline" data-astro-cid-lcdefpme>real exam hall</span>.</h1><p class="hero-sub" data-astro-cid-lcdefpme>Server-timed CBT mocks with the exact palette, section locks and negative marking of SSC, Banking, Railways, UPSC and State PCS papers — plus video courses and analytics that tell you precisely where marks are leaking.</p><div class="hero-actions" data-astro-cid-lcdefpme><a${addAttribute(`${spaUrl}/register`, "href")} class="btn-primary" data-astro-cid-lcdefpme>Start preparing free</a><a href="/courses" class="btn-secondary" data-astro-cid-lcdefpme>Browse courses</a></div><div class="hero-proof" data-astro-cid-lcdefpme><span class="omr-strip" aria-hidden="true" data-astro-cid-lcdefpme><i class="filled" data-astro-cid-lcdefpme></i><i data-astro-cid-lcdefpme></i><i class="marker" data-astro-cid-lcdefpme></i><i data-astro-cid-lcdefpme></i><i class="filled" data-astro-cid-lcdefpme></i></span><span data-astro-cid-lcdefpme>Server-authoritative timer · Autosave every answer · Resume after any crash</span></div></div><!-- Hero Visual with Indian Student Image & CBT simulator card --><div class="hero-visual" data-astro-cid-lcdefpme><div class="hero-image-frame" data-astro-cid-lcdefpme><div class="vector-outline-box" data-astro-cid-lcdefpme></div><div class="red-circle-accent" data-astro-cid-lcdefpme></div><img src="/images/hero-student.png" alt="Indian Student preparing for CBT exam" class="hero-student-img" data-astro-cid-lcdefpme><!-- Floating compact CBT simulator badge --><div class="glass-panel hero-sim-overlay" data-astro-cid-lcdefpme><div class="mini-badge-head" data-astro-cid-lcdefpme><span class="mini-timer" data-astro-cid-lcdefpme>⚡ 00:47:12</span></div><p class="mini-test-title" data-astro-cid-lcdefpme>SSC CGL Tier I Mock</p><div class="mini-status-chip" data-astro-cid-lcdefpme>CBT Live Pattern</div></div><!-- Floating compact Percentile badge --><div class="glass-panel hero-rank-overlay" data-astro-cid-lcdefpme><span class="rank-label" data-astro-cid-lcdefpme>TOP PERCENTILE</span><span class="rank-value" data-astro-cid-lcdefpme>99.4%</span><span class="rank-sub" data-astro-cid-lcdefpme>Rank 12 in Batch</span></div></div></div></div></section><section class="tracks reveal" data-astro-cid-lcdefpme><div class="wrap" data-astro-cid-lcdefpme><span class="section-label" data-astro-cid-lcdefpme><span class="idx" data-astro-cid-lcdefpme>01</span> Exam categories</span><h2 class="sec-title" data-astro-cid-lcdefpme>Pick your battlefield.</h2><div class="tracks-grid" data-astro-cid-lcdefpme>${examTracks.map((t) => renderTemplate`<a href="/courses" class="ticket glass-panel glass-panel-hover" data-astro-cid-lcdefpme><span class="ticket-stub" data-astro-cid-lcdefpme>ADMIT</span><span class="ticket-body" data-astro-cid-lcdefpme><span class="ticket-code" data-astro-cid-lcdefpme>${t.code}</span><span class="ticket-title" data-astro-cid-lcdefpme>${t.title}</span><span class="ticket-subjects" data-astro-cid-lcdefpme>${t.subjects}</span><span class="ticket-note" data-astro-cid-lcdefpme>${t.note}</span><span class="ticket-cta" data-astro-cid-lcdefpme>View mock series →</span></span></a>`)}</div></div></section><section class="catalog reveal" data-astro-cid-lcdefpme><div class="wrap" data-astro-cid-lcdefpme>${renderComponent($$result2, "CourseCarousel", $$CourseCarousel, { "data-astro-cid-lcdefpme": true })}</div></section><section class="steps reveal" data-astro-cid-lcdefpme><div class="wrap" data-astro-cid-lcdefpme><span class="section-label" data-astro-cid-lcdefpme><span class="idx" data-astro-cid-lcdefpme>02</span> How it works</span><h2 class="sec-title" data-astro-cid-lcdefpme>From sign-up to scorecard in three steps.</h2><ol class="steps-row" data-astro-cid-lcdefpme><li data-astro-cid-lcdefpme><span class="stamp" data-astro-cid-lcdefpme>1</span><h3 data-astro-cid-lcdefpme>Register &amp; verify</h3><p data-astro-cid-lcdefpme>Create your free account, verify your email and mobile with an OTP — takes two minutes.</p></li><li data-astro-cid-lcdefpme><span class="stamp" data-astro-cid-lcdefpme>2</span><h3 data-astro-cid-lcdefpme>Activate your batch</h3><p data-astro-cid-lcdefpme>Enter the activation code from your institute, or pay online for instant access when enrolment is open.</p></li><li data-astro-cid-lcdefpme><span class="stamp" data-astro-cid-lcdefpme>3</span><h3 data-astro-cid-lcdefpme>Practise &amp; analyse</h3><p data-astro-cid-lcdefpme>Attempt timed mocks, watch structured lessons, and track accuracy, percentile and rank after every test.</p></li></ol></div></section><section class="deep reveal" data-astro-cid-lcdefpme><div class="wrap" data-astro-cid-lcdefpme><span class="section-label" data-astro-cid-lcdefpme><span class="idx" data-astro-cid-lcdefpme>03</span> Built like the real thing</span><h2 class="sec-title" data-astro-cid-lcdefpme>Every detail of the exam hall, replicated.</h2><div class="deep-row" data-astro-cid-lcdefpme><div class="deep-copy" data-astro-cid-lcdefpme><h3 data-astro-cid-lcdefpme>The five-state palette, exactly as SSC &amp; IBPS render it</h3><p data-astro-cid-lcdefpme>Answered, not answered, marked for review, answered &amp; marked, not visited — the same colours, the same teardrop shape, the same section locks. When you sit the real CBT, nothing will surprise you.</p><div class="legend" data-astro-cid-lcdefpme><span data-astro-cid-lcdefpme><span class="pal green" data-astro-cid-lcdefpme>1</span> Answered</span><span data-astro-cid-lcdefpme><span class="pal red" data-astro-cid-lcdefpme>2</span> Not answered</span><span data-astro-cid-lcdefpme><span class="pal violet" data-astro-cid-lcdefpme>3</span> Marked</span><span data-astro-cid-lcdefpme><span class="pal violet-green" data-astro-cid-lcdefpme>4</span> Ans + marked</span><span data-astro-cid-lcdefpme><span class="pal gray" data-astro-cid-lcdefpme>5</span> Not visited</span></div></div><div class="deep-visual glass-panel" data-astro-cid-lcdefpme><p class="dv-title" data-astro-cid-lcdefpme>SECTION TIMER · SERVER-SIDE</p><p class="dv-clock" data-astro-cid-lcdefpme>00:12:0<span class="tick" data-astro-cid-lcdefpme>4</span></p><p class="dv-note" data-astro-cid-lcdefpme>Auto-submit fires on the server when time expires — even if your tab is closed.</p></div></div><div class="deep-row rev" data-astro-cid-lcdefpme><div class="deep-copy" data-astro-cid-lcdefpme><h3 data-astro-cid-lcdefpme>Analytics that name the problem, not just the score</h3><p data-astro-cid-lcdefpme>Every submission is re-scored on the server from your raw answers. Accuracy, time-per-question, subject and topic breakdowns, batch percentile and rank — recomputed, never estimated.</p></div><div class="deep-visual glass-panel" data-astro-cid-lcdefpme><p class="dv-title" data-astro-cid-lcdefpme>SUBJECT ACCURACY · MOCK 04</p><div class="bars" data-astro-cid-lcdefpme><div class="bar" data-astro-cid-lcdefpme><span data-astro-cid-lcdefpme>Quant</span><div class="bar-track" data-astro-cid-lcdefpme><i style="width: 82%" data-astro-cid-lcdefpme></i></div><b data-astro-cid-lcdefpme>82%</b></div><div class="bar" data-astro-cid-lcdefpme><span data-astro-cid-lcdefpme>Reasoning</span><div class="bar-track" data-astro-cid-lcdefpme><i style="width: 74%" data-astro-cid-lcdefpme></i></div><b data-astro-cid-lcdefpme>74%</b></div><div class="bar" data-astro-cid-lcdefpme><span data-astro-cid-lcdefpme>English</span><div class="bar-track" data-astro-cid-lcdefpme><i style="width: 91%" data-astro-cid-lcdefpme></i></div><b data-astro-cid-lcdefpme>91%</b></div><div class="bar weak" data-astro-cid-lcdefpme><span data-astro-cid-lcdefpme>GA</span><div class="bar-track" data-astro-cid-lcdefpme><i style="width: 48%" data-astro-cid-lcdefpme></i></div><b data-astro-cid-lcdefpme>48%</b></div></div><p class="dv-note" data-astro-cid-lcdefpme>GA is leaking marks → the system says so, plainly.</p></div></div><div class="deep-row" data-astro-cid-lcdefpme><div class="deep-copy" data-astro-cid-lcdefpme><h3 data-astro-cid-lcdefpme>Structured video courses with resume-anywhere progress</h3><p data-astro-cid-lcdefpme>Modules and lessons in exam order, watched-seconds logged automatically. Close the tab mid-lecture and the player reopens within a few seconds of where you stopped — on any device.</p></div><div class="deep-visual glass-panel" data-astro-cid-lcdefpme><p class="dv-title" data-astro-cid-lcdefpme>MODULE 03 · ALGEBRA</p><div class="lessons" data-astro-cid-lcdefpme><div class="lesson done" data-astro-cid-lcdefpme><i data-astro-cid-lcdefpme>✓</i><span data-astro-cid-lcdefpme>Linear equations — shortcuts</span><b data-astro-cid-lcdefpme>18:40</b></div><div class="lesson done" data-astro-cid-lcdefpme><i data-astro-cid-lcdefpme>✓</i><span data-astro-cid-lcdefpme>Quadratic identities drill</span><b data-astro-cid-lcdefpme>22:15</b></div><div class="lesson now" data-astro-cid-lcdefpme><i data-astro-cid-lcdefpme>▶</i><span data-astro-cid-lcdefpme>Ratio &amp; proportion masterclass</span><b data-astro-cid-lcdefpme>12:03 / 31:20</b></div><div class="lesson" data-astro-cid-lcdefpme><i data-astro-cid-lcdefpme>·</i><span data-astro-cid-lcdefpme>Mixture &amp; alligation</span><b data-astro-cid-lcdefpme>26:48</b></div></div></div></div></div></section><section class="aspirants-spotlight reveal" data-astro-cid-lcdefpme><div class="wrap" data-astro-cid-lcdefpme><div class="spotlight-container glass-panel" data-astro-cid-lcdefpme><div class="spotlight-grid" data-astro-cid-lcdefpme><div class="spotlight-copy" data-astro-cid-lcdefpme><span class="badge" data-astro-cid-lcdefpme>Trusted by 15,000+ Aspirants</span><h2 data-astro-cid-lcdefpme>Join India's Most Accurate CBT Mock Test Series</h2><p data-astro-cid-lcdefpme>Designed by top exam rankers. Engineered for SSC CGL, SBI PO, IBPS, Railways RRB, UPSC, and State PCS aspirants across India.</p><div class="spotlight-stats" data-astro-cid-lcdefpme><div class="stat-box" data-astro-cid-lcdefpme><span class="stat-num" data-astro-cid-lcdefpme>15k+</span><span class="stat-lbl" data-astro-cid-lcdefpme>Active Students</span></div><div class="stat-box" data-astro-cid-lcdefpme><span class="stat-num" data-astro-cid-lcdefpme>98.4%</span><span class="stat-lbl" data-astro-cid-lcdefpme>Exam Accuracy</span></div><div class="stat-box" data-astro-cid-lcdefpme><span class="stat-num" data-astro-cid-lcdefpme>100%</span><span class="stat-lbl" data-astro-cid-lcdefpme>CBT Pattern Sync</span></div></div></div><div class="spotlight-visual" data-astro-cid-lcdefpme><div class="group-frame" data-astro-cid-lcdefpme><div class="rounded-contour-line" data-astro-cid-lcdefpme></div><img src="/images/toppers-group.png" alt="Successful Indian Aspirants Study Lounge" class="toppers-img" data-astro-cid-lcdefpme><div class="topper-badge badge-1" data-astro-cid-lcdefpme>100% CBT Exam Engine</div><div class="topper-badge badge-2" data-astro-cid-lcdefpme>All-India Rank Percentile</div></div></div></div></div></div></section><section class="facts reveal" data-astro-cid-lcdefpme><div class="wrap facts-band glass-panel" data-astro-cid-lcdefpme><div class="fact" data-astro-cid-lcdefpme><span class="fact-n" data-astro-cid-lcdefpme>05</span><span class="fact-l" data-astro-cid-lcdefpme>palette states, exam-exact</span></div><div class="fact" data-astro-cid-lcdefpme><span class="fact-n" data-astro-cid-lcdefpme>±1s</span><span class="fact-l" data-astro-cid-lcdefpme>server-timer accuracy</span></div><div class="fact" data-astro-cid-lcdefpme><span class="fact-n" data-astro-cid-lcdefpme>06</span><span class="fact-l" data-astro-cid-lcdefpme>exam categories covered</span></div><div class="fact" data-astro-cid-lcdefpme><span class="fact-n" data-astro-cid-lcdefpme>100%</span><span class="fact-l" data-astro-cid-lcdefpme>server-side scoring</span></div></div></section><section class="voices reveal" data-astro-cid-lcdefpme><div class="wrap" data-astro-cid-lcdefpme><span class="section-label" data-astro-cid-lcdefpme><span class="idx" data-astro-cid-lcdefpme>04</span> Aspirant voices</span><h2 class="sec-title" data-astro-cid-lcdefpme>Margin notes from the study table.</h2><div class="voices-grid" data-astro-cid-lcdefpme><figure class="voice glass-panel" data-astro-cid-lcdefpme><blockquote data-astro-cid-lcdefpme>“The palette behaves exactly like the real SSC CBT. My first actual exam felt like my 30th mock.”</blockquote><figcaption data-astro-cid-lcdefpme><b data-astro-cid-lcdefpme>Ananya S.</b> · SSC CGL aspirant</figcaption></figure><figure class="voice glass-panel" data-astro-cid-lcdefpme><blockquote data-astro-cid-lcdefpme>“Percentile after every mock kept me honest. GA was my leak — the analytics said it before my teacher did.”</blockquote><figcaption data-astro-cid-lcdefpme><b data-astro-cid-lcdefpme>Rohit K.</b> · IBPS PO aspirant</figcaption></figure><figure class="voice glass-panel" data-astro-cid-lcdefpme><blockquote data-astro-cid-lcdefpme>“Internet died mid-mock. Logged back in, timer and answers were all intact. That sold me.”</blockquote><figcaption data-astro-cid-lcdefpme><b data-astro-cid-lcdefpme>Meera D.</b> · RRB NTPC aspirant</figcaption></figure></div></div></section><section class="faq reveal" data-astro-cid-lcdefpme><div class="wrap" data-astro-cid-lcdefpme><span class="section-label" data-astro-cid-lcdefpme><span class="idx" data-astro-cid-lcdefpme>05</span> Questions, answered</span><h2 class="sec-title" data-astro-cid-lcdefpme>Before you ask.</h2><div class="faq-list" data-astro-cid-lcdefpme>${faqs.map((f) => renderTemplate`<details class="faq-item glass-panel" data-astro-cid-lcdefpme><summary data-astro-cid-lcdefpme>${f.q}</summary><p data-astro-cid-lcdefpme>${f.a}</p></details>`)}</div></div></section><section class="final reveal" data-astro-cid-lcdefpme><div class="wrap final-band glass-panel" data-astro-cid-lcdefpme><div class="final-copy" data-astro-cid-lcdefpme><h2 data-astro-cid-lcdefpme>Your seat in the exam hall starts here.</h2><p data-astro-cid-lcdefpme>Free account · verify in minutes · your institute's code unlocks everything.</p></div><div class="final-actions" data-astro-cid-lcdefpme><a${addAttribute(`${spaUrl}/register`, "href")} class="btn-primary" data-astro-cid-lcdefpme>Create free account</a><a href="/courses" class="btn-secondary" data-astro-cid-lcdefpme>See all courses</a></div></div></section>` })}`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/index.astro", void 0);
var $$file = "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/index.astro";
//#endregion
//#region \0virtual:astro:page:src/pages/index@_@astro
var page = () => pages_exports;
//#endregion
export { page };
