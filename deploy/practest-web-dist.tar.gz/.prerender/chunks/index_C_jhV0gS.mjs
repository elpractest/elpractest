import { n as createComponent, r as __exportAll, t as $$Layout } from "./Layout_DzppV3bk.mjs";
import { g as defineScriptVars, l as renderTemplate, p as maybeRenderHead, r as renderComponent } from "./server_BmHvQwWi.mjs";
//#region src/pages/courses/index.astro
var courses_exports = /* @__PURE__ */ __exportAll({
	default: () => $$Index,
	file: () => $$file,
	url: () => $$url
});
var $$Index = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": "All Courses - Practest mock tests and LMS lectures",
		"data-astro-cid-systoabk": true
	}, { "default": ($$result2) => renderTemplate`${maybeRenderHead($$result2)}<div class="courses-page-container" data-astro-cid-systoabk><div class="courses-header" data-astro-cid-systoabk><h1 data-astro-cid-systoabk>Our Course Catalogue</h1><p data-astro-cid-systoabk>Explore high-quality study materials, video lectures, and timed practice test series.</p></div><!-- Live Courses Grid (Hydrated Client-Side) --><div id="loading-spinner" class="loading-state" data-astro-cid-systoabk><div class="spinner" data-astro-cid-systoabk></div><p data-astro-cid-systoabk>Loading course catalog...</p></div><div id="error-state" class="error-state" style="display: none;" data-astro-cid-systoabk><p data-astro-cid-systoabk>Failed to load the course catalog. Please refresh the page.</p></div><div id="empty-state" class="empty-state" style="display: none;" data-astro-cid-systoabk><p data-astro-cid-systoabk>No active courses are available at the moment. Please check back later.</p></div><div id="courses-grid" class="courses-grid" style="display: none;" data-astro-cid-systoabk><!-- Hydrated by JS --></div></div>` })}<script>(function(){${defineScriptVars({ apiUrl: "https://api.practest.live" })}
  async function fetchCourses() {
    const spinner = document.getElementById('loading-spinner');
    const errorState = document.getElementById('error-state');
    const emptyState = document.getElementById('empty-state');
    const grid = document.getElementById('courses-grid');

    try {
      const response = await fetch(\`\${apiUrl}/api/courses/public\`);
      if (!response.ok) throw new Error('API response not ok');
      const courses = await response.json();

      spinner.style.display = 'none';

      if (!courses || courses.length === 0) {
        emptyState.style.display = 'block';
        return;
      }

      // Render courses
      grid.innerHTML = courses.map(course => {
        // Find cheapest active batch price
        const prices = (course.batches || [])
          .map(b => b.price_paise)
          .filter(p => p !== null && p !== undefined);
        
        let priceTag = 'Free / Contact Us';
        if (prices.length > 0) {
          const minPrice = Math.min(...prices);
          priceTag = \`Starts from ₹\${(minPrice / 100).toLocaleString()}\`;
        }

        return \`
          <div class="glass-panel glass-panel-hover course-card" style="padding: 0; display: flex; flex-direction: column; overflow: hidden;">
            <div style="position: relative; width: 100%; height: 180px; overflow: hidden; border-bottom: 1px solid var(--border-color);">
              <img src="\${course.banner_url || '/images/course-placeholder.svg'}" alt="\${escapeHtml(course.title)}" style="width: 100%; height: 100%; object-fit: cover;" />
              <div class="course-badge" style="position: absolute; top: 16px; right: 16px; background: rgba(0, 0, 0, 0.75); color: #fff; border: 1px solid rgba(255, 255, 255, 0.15); border-radius: 4px; font-size: 0.75rem; font-weight: 700; padding: 4px 10px; margin: 0;">\${course.exam_category || 'General'}</div>
            </div>
            
            <div class="course-info" style="padding: 24px; display: flex; flex-direction: column; gap: 12px; flex-grow: 1; margin: 0;">
              <h2>\${escapeHtml(course.title)}</h2>
              <p class="course-desc">\${escapeHtml(course.short_description || course.description || '')}</p>
              
              <div class="course-meta" style="display: flex; justify-content: space-between; align-items: center; margin-top: auto; padding-top: 12px; border-top: 1px solid var(--border-color); width: 100%;">
                <span class="course-mode">💻 \${capitalize(course.mode || 'online')}</span>
                <span class="course-price" style="font-weight: 700; color: var(--accent-color);">\${priceTag}</span>
              </div>

              <a href="/courses/\${course.slug}" class="btn-primary view-btn" style="width: 100%; text-align: center; margin-top: 12px;">
                View Course Details
              </a>
            </div>
          </div>
        \`;
      }).join('');

      grid.style.display = 'grid';

    } catch (err) {
      console.error('Error fetching public courses:', err);
      spinner.style.display = 'none';
      errorState.style.display = 'block';
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  // Load courses
  fetchCourses();
})();<\/script>`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/courses/index.astro", void 0);
var $$file = "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/courses/index.astro";
var $$url = "/courses";
//#endregion
//#region \0virtual:astro:page:src/pages/courses/index@_@astro
var page = () => courses_exports;
//#endregion
export { page };
