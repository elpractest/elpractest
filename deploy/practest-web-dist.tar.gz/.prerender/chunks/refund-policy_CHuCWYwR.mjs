import { n as createComponent, r as __exportAll, t as $$Layout } from "./Layout_DzppV3bk.mjs";
import { l as renderTemplate, p as maybeRenderHead, r as renderComponent } from "./server_BmHvQwWi.mjs";
//#region src/pages/refund-policy.astro
var refund_policy_exports = /* @__PURE__ */ __exportAll({
	default: () => $$RefundPolicy,
	file: () => $$file,
	url: () => $$url
});
var $$RefundPolicy = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": "Cancellation & Refund Policy — e-Learning Practest",
		"description": "Cancellation and Refund Policy for e-Learning Practest (Vinstitution / VPD Vastus Ventures Pvt. Ltd.).",
		"data-astro-cid-yiawqtqj": true
	}, { "default": ($$result) => renderTemplate`${maybeRenderHead($$result)}<section class="legal-hero" data-astro-cid-yiawqtqj><div class="legal-container" data-astro-cid-yiawqtqj><span class="badge" data-astro-cid-yiawqtqj>Legal & Compliance</span><h1 data-astro-cid-yiawqtqj>Cancellation & Refund Policy</h1><p class="subtitle" data-astro-cid-yiawqtqj>Last updated: July 2026</p></div></section><section class="legal-content" data-astro-cid-yiawqtqj><div class="legal-container card" data-astro-cid-yiawqtqj><h2 data-astro-cid-yiawqtqj>1. Overview</h2><p data-astro-cid-yiawqtqj>At e-Learning Practest (a brand of Vinstitution / VPD Vastus Ventures Private Limited), we strive to provide high-quality online mock test series and course materials. Because digital access (including mock test questions and LMS video lessons) is granted immediately upon course activation or activation code redemption, our refund policy operates under the following terms.</p><h2 data-astro-cid-yiawqtqj>2. Cancellation Policy</h2><p data-astro-cid-yiawqtqj>Students can request batch activation cancellation prior to course activation. Once an activation code has been redeemed or an online payment transaction has been processed and access granted, requests for cancellation are evaluated on a case-by-case basis.</p><h2 data-astro-cid-yiawqtqj>3. Refund Eligibility</h2><ul data-astro-cid-yiawqtqj><li data-astro-cid-yiawqtqj><strong data-astro-cid-yiawqtqj>Duplicate Transactions:</strong> If an online payment is charged twice due to a technical glitch, a 100% refund of the duplicate amount will be processed automatically within 5–7 working days to the original payment method.</li><li data-astro-cid-yiawqtqj><strong data-astro-cid-yiawqtqj>Service Inaccessibility:</strong> If technical failure on our platform prevents access to purchased courses for more than 7 consecutive days, students may request a pro-rata refund.</li><li data-astro-cid-yiawqtqj><strong data-astro-cid-yiawqtqj>Non-Refundable Circumstances:</strong> Refunds will not be granted after a student has attempted 1 or more full mock tests within the course batch or redeemed an activation code.</li></ul><h2 data-astro-cid-yiawqtqj>4. Processing Time</h2><p data-astro-cid-yiawqtqj>Approved refunds will be credited back to the original source account (Bank Account, Credit/Debit Card, or UPI) within 5–7 business days from the date of approval.</p><h2 data-astro-cid-yiawqtqj>5. Support & Grievance Contact</h2><p data-astro-cid-yiawqtqj>To submit a refund or cancellation request, please email our support team with your registered email, phone number, and payment reference:</p><address data-astro-cid-yiawqtqj><strong data-astro-cid-yiawqtqj>Refund Support Desk</strong><br data-astro-cid-yiawqtqj>Email: <a href="mailto:support@practest.live" data-astro-cid-yiawqtqj>support@practest.live</a><br data-astro-cid-yiawqtqj>Phone: <a href="tel:+919310959596" data-astro-cid-yiawqtqj>+91 93109 59596</a></address></div></section>` })}`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/refund-policy.astro", void 0);
var $$file = "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/refund-policy.astro";
var $$url = "/refund-policy";
//#endregion
//#region \0virtual:astro:page:src/pages/refund-policy@_@astro
var page = () => refund_policy_exports;
//#endregion
export { page };
