import { I as AstroError, K as InvalidComponentArgs, S as createAstro, _ as createRenderInstruction, b as unescapeHTML, h as addAttribute, l as renderTemplate, m as renderHead, o as renderSlot, p as maybeRenderHead, r as renderComponent } from "./server_BmHvQwWi.mjs";
//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region node_modules/astro/dist/runtime/server/astro-component.js
function validateArgs(args) {
	if (args.length !== 3) return false;
	if (!args[0] || typeof args[0] !== "object") return false;
	return true;
}
function baseCreateComponent(cb, moduleId, propagation) {
	const name = moduleId?.split("/").pop()?.replace(".astro", "") ?? "";
	const fn = (...args) => {
		if (!validateArgs(args)) throw new AstroError({
			...InvalidComponentArgs,
			message: InvalidComponentArgs.message(name)
		});
		return cb(...args);
	};
	Object.defineProperty(fn, "name", {
		value: name,
		writable: false
	});
	fn.isAstroComponentFactory = true;
	fn.moduleId = moduleId;
	fn.propagation = propagation;
	return fn;
}
function createComponentWithOptions(opts) {
	return baseCreateComponent(opts.factory, opts.moduleId, opts.propagation);
}
function createComponent(arg1, moduleId, propagation) {
	if (typeof arg1 === "function") return baseCreateComponent(arg1, moduleId, propagation);
	else return createComponentWithOptions(arg1);
}
//#endregion
//#region node_modules/astro/dist/runtime/server/render/script.js
async function renderScript(result, id) {
	const inlined = result.inlinedScripts.get(id);
	let content = "";
	if (inlined != null) {
		if (inlined) content = `<script type="module">${inlined}<\/script>`;
	} else {
		const resolved = await result.resolve(id);
		content = `<script type="module" src="${result.userAssetsBase ? (result.base === "/" ? "" : result.base) + result.userAssetsBase : ""}${resolved}"><\/script>`;
	}
	return createRenderInstruction({
		type: "script",
		id,
		content
	});
}
//#endregion
//#region src/components/Analytics.astro
var $$Analytics = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${""}`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/components/Analytics.astro", void 0);
//#endregion
//#region src/components/ConsentBanner.astro
var $$ConsentBanner = createComponent(($$result, $$props, $$slots) => {
	return renderTemplate`${maybeRenderHead($$result)}<div id="consent-banner" class="glass-panel consent-banner" style="display: none;" data-astro-cid-u6s5b3h2><div class="consent-content" data-astro-cid-u6s5b3h2><span class="consent-icon" data-astro-cid-u6s5b3h2>🍪</span><p data-astro-cid-u6s5b3h2>We use cookies to improve your mock exam and learning experience. By clicking "Accept", you agree to our analytics trackers (GA4, Meta Pixel).</p></div><div class="consent-actions" data-astro-cid-u6s5b3h2><button id="consent-decline" class="btn-secondary" data-astro-cid-u6s5b3h2>Decline</button><button id="consent-accept" class="btn-primary" data-astro-cid-u6s5b3h2>Accept</button></div></div>${renderScript($$result, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/components/ConsentBanner.astro?astro&type=script&index=0&lang.ts")}`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/components/ConsentBanner.astro", void 0);
//#endregion
//#region src/layouts/Layout.astro
createAstro("https://www.practest.live");
var $$Layout = createComponent(($$result, $$props, $$slots) => {
	const Astro2 = $$result.createAstro($$props, $$slots);
	Astro2.self = $$Layout;
	const { title = "e-Learning Practest — Mock Test Series & LMS for Govt Exams", description = "e-Learning Practest — exam-pattern CBT mock tests for SSC, Banking, Railways, UPSC & State PCS with server-timed sections, deep analytics and structured video courses. A Vinstitution brand." } = Astro2.props;
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	const spaUrl = "https://app.practest.live";
	const siteUrl = "https://www.practest.live";
	const canonicalUrl = new URL(Astro2.url.pathname, siteUrl).href;
	const orgSchema = JSON.stringify({
		"@context": "https://schema.org",
		"@type": "Organization",
		"name": "Practest",
		"url": siteUrl,
		"logo": `${siteUrl}/logo.png`,
		"description": description,
		"sameAs": []
	});
	return renderTemplate`<html lang="en" data-theme="dark" data-astro-cid-ju4pidww><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><link rel="icon" href="/favicon.ico"><link rel="canonical"${addAttribute(canonicalUrl, "href")}><meta name="generator"${addAttribute(Astro2.generator, "content")}><!-- Theme boot: cookie (shared with the app subdomain) → localStorage → dark --><script>
      (function () {
        try {
          var m = document.cookie.match(/(?:^|; )practest_theme=(light|dark)/);
          var t = m ? m[1] : localStorage.getItem('practest-theme');
          if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t;
        } catch (e) { /* default dark stands */ }
      })();
    <\/script><!-- Primary Meta Tags --><title>${title}</title><meta name="title"${addAttribute(title, "content")}><meta name="description"${addAttribute(description, "content")}><meta name="theme-color" content="#070b16" media="(prefers-color-scheme: dark)"><meta name="theme-color" content="#f3f1ea" media="(prefers-color-scheme: light)"><!-- Open Graph / Facebook --><meta property="og:type" content="website"><meta property="og:title"${addAttribute(title, "content")}><meta property="og:description"${addAttribute(description, "content")}><meta property="og:url"${addAttribute(canonicalUrl, "content")}><meta property="og:image" content="/og-image.png"><!-- Twitter --><meta property="twitter:card" content="summary_large_image"><meta property="twitter:title"${addAttribute(title, "content")}><meta property="twitter:description"${addAttribute(description, "content")}><meta property="twitter:image" content="/og-image.png"><!-- Schema.org Organization --><script type="application/ld+json">${unescapeHTML(orgSchema)}<\/script><!-- Fonts: Space Grotesk (display) · Inter (UI) · JetBrains Mono (data) --><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@500;700&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">${renderHead($$result)}</head><body data-astro-cid-ju4pidww>${renderComponent($$result, "Analytics", $$Analytics, { "data-astro-cid-ju4pidww": true })}${renderComponent($$result, "ConsentBanner", $$ConsentBanner, { "data-astro-cid-ju4pidww": true })}<div class="layout-wrapper" data-astro-cid-ju4pidww><header class="navbar-header" data-astro-cid-ju4pidww><div class="navbar-container" data-astro-cid-ju4pidww><a href="/" class="brand-logo" aria-label="e-Learning Practest home" data-astro-cid-ju4pidww><span class="logo-tile" aria-hidden="true" data-astro-cid-ju4pidww><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-ju4pidww><path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z" data-astro-cid-ju4pidww></path><path d="M22 10v6" data-astro-cid-ju4pidww></path><path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5" data-astro-cid-ju4pidww></path></svg></span><span class="brand-lockup" data-astro-cid-ju4pidww><span class="brand-pre" data-astro-cid-ju4pidww>e-Learning</span><span class="brand-name" data-astro-cid-ju4pidww>Practest<sup class="brand-r" data-astro-cid-ju4pidww>®</sup></span></span></a><nav class="navbar-links" aria-label="Main" data-astro-cid-ju4pidww><a href="/courses" data-astro-cid-ju4pidww>Courses</a><a href="/about" data-astro-cid-ju4pidww>About</a><a href="/contact" data-astro-cid-ju4pidww>Contact</a></nav><div class="navbar-actions" data-astro-cid-ju4pidww><button id="theme-toggle" class="theme-toggle-btn" type="button" aria-label="Switch between day and night mode" title="Day / night mode" data-astro-cid-ju4pidww><svg class="icon-sun" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-ju4pidww><circle cx="12" cy="12" r="4" data-astro-cid-ju4pidww></circle><path d="M12 2v2" data-astro-cid-ju4pidww></path><path d="M12 20v2" data-astro-cid-ju4pidww></path><path d="m4.93 4.93 1.41 1.41" data-astro-cid-ju4pidww></path><path d="m17.66 17.66 1.41 1.41" data-astro-cid-ju4pidww></path><path d="M2 12h2" data-astro-cid-ju4pidww></path><path d="M20 12h2" data-astro-cid-ju4pidww></path><path d="m6.34 17.66-1.41 1.41" data-astro-cid-ju4pidww></path><path d="m19.07 4.93-1.41 1.41" data-astro-cid-ju4pidww></path></svg><svg class="icon-moon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-ju4pidww><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" data-astro-cid-ju4pidww></path></svg></button><a${addAttribute(`${spaUrl}/login`, "href")} class="btn-secondary nav-login" data-astro-cid-ju4pidww>Login</a><a${addAttribute(`${spaUrl}/register`, "href")} class="btn-primary nav-cta" data-astro-cid-ju4pidww>Start free</a></div></div></header><main class="main-content" data-astro-cid-ju4pidww>${renderSlot($$result, $$slots["default"])}</main><footer class="footer" data-astro-cid-ju4pidww><div class="footer-container" data-astro-cid-ju4pidww><div class="footer-info" data-astro-cid-ju4pidww><a href="/" class="brand-logo" style="margin-bottom: 14px;" data-astro-cid-ju4pidww><span class="logo-tile" aria-hidden="true" data-astro-cid-ju4pidww><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-ju4pidww><path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z" data-astro-cid-ju4pidww></path><path d="M22 10v6" data-astro-cid-ju4pidww></path><path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5" data-astro-cid-ju4pidww></path></svg></span><span class="brand-lockup" data-astro-cid-ju4pidww><span class="brand-pre" data-astro-cid-ju4pidww>e-Learning</span><span class="brand-name" data-astro-cid-ju4pidww>Practest<sup class="brand-r" data-astro-cid-ju4pidww>®</sup></span></span></a><p class="footer-tag" data-astro-cid-ju4pidww>Exam-pattern CBT mocks, structured video courses and honest analytics — the flagship exam-prep platform of <strong data-astro-cid-ju4pidww>Vinstitution</strong>.</p><div class="omr-strip" aria-hidden="true" data-astro-cid-ju4pidww><i data-astro-cid-ju4pidww></i><i class="filled" data-astro-cid-ju4pidww></i><i data-astro-cid-ju4pidww></i><i class="marker" data-astro-cid-ju4pidww></i><i data-astro-cid-ju4pidww></i></div></div><div class="footer-links-group" data-astro-cid-ju4pidww><div class="footer-col" data-astro-cid-ju4pidww><h4 data-astro-cid-ju4pidww>Prepare</h4><a href="/courses" data-astro-cid-ju4pidww>All courses</a><a${addAttribute(`${spaUrl}/register`, "href")} data-astro-cid-ju4pidww>Create account</a><a${addAttribute(`${spaUrl}/login`, "href")} data-astro-cid-ju4pidww>Student login</a></div><div class="footer-col" data-astro-cid-ju4pidww><h4 data-astro-cid-ju4pidww>Exams</h4><a href="/courses" data-astro-cid-ju4pidww>SSC CGL</a><a href="/courses" data-astro-cid-ju4pidww>Banking — SBI · IBPS</a><a href="/courses" data-astro-cid-ju4pidww>Railways RRB</a><a href="/courses" data-astro-cid-ju4pidww>UPSC & State PCS</a></div><div class="footer-col" data-astro-cid-ju4pidww><h4 data-astro-cid-ju4pidww>Company</h4><a href="/about" data-astro-cid-ju4pidww>About us</a><a href="/contact" data-astro-cid-ju4pidww>Contact</a><a href="/privacy" data-astro-cid-ju4pidww>Privacy Policy</a><a href="/terms" data-astro-cid-ju4pidww>Terms of Service</a><a href="/refund-policy" data-astro-cid-ju4pidww>Refund Policy</a></div><div class="footer-col footer-office" data-astro-cid-ju4pidww><h4 data-astro-cid-ju4pidww>Registered Office</h4><address data-astro-cid-ju4pidww>Vinstitution, 2nd Floor, Property No. 44,<br data-astro-cid-ju4pidww>Regal Building, Connaught Place,<br data-astro-cid-ju4pidww>New Delhi — 110090</address><a href="tel:+919310959596" data-astro-cid-ju4pidww>+91 93109 59596</a></div></div></div><div class="footer-corporate" data-astro-cid-ju4pidww><p class="corp-parent" data-astro-cid-ju4pidww><strong data-astro-cid-ju4pidww>e-Learning Practest<sup class="brand-r" data-astro-cid-ju4pidww>®</sup></strong> is a brand of the<strong data-astro-cid-ju4pidww>Vinstitution</strong> segment of<strong data-astro-cid-ju4pidww>VPD Vastus Ventures Private Limited</strong>.</p><p class="corp-creds" data-astro-cid-ju4pidww>PAN: AAMCV2938B · GSTIN: 07AAMCV2938B1ZA · ISO 9001:2015 Certified</p></div><div class="footer-bottom" data-astro-cid-ju4pidww><p data-astro-cid-ju4pidww>© ${year} VPD Vastus Ventures Pvt. Ltd. All rights reserved. · Proudly powered by <strong class="pw" data-astro-cid-ju4pidww>Vinstitution</strong> · Designed by <a href="https://vgraphics.in" target="_blank" rel="noopener" data-astro-cid-ju4pidww>VGraphics.in</a></p></div></footer></div><!-- Floating contact actions (real number: +91 93109 59596) --><div class="fab-stack" aria-label="Quick contact" data-astro-cid-ju4pidww><a class="fab fab-wa" href="https://wa.me/919310959596?text=Hi%21%20I%27d%20like%20to%20know%20more%20about%20e-Learning%20Practest%20courses." target="_blank" rel="noopener" aria-label="Chat with us on WhatsApp" data-astro-cid-ju4pidww><svg class="fab-ico" viewBox="0 0 32 32" fill="currentColor" aria-hidden="true" data-astro-cid-ju4pidww><path d="M16.004 0h-.008C7.174 0 .002 7.173.002 16c0 3.5 1.128 6.742 3.046 9.377L1.05 31.02l5.83-1.863A15.9 15.9 0 0 0 16.004 32C24.83 32 32 24.826 32 16S24.83 0 16.004 0zm9.32 22.61c-.386 1.09-1.92 1.995-3.144 2.26-.836.178-1.928.32-5.604-1.204-4.703-1.95-7.73-6.73-7.966-7.04-.226-.31-1.9-2.53-1.9-4.827 0-2.296 1.206-3.425 1.634-3.89.386-.42.842-.51 1.122-.51.28 0 .56.003.804.015.258.013.604-.098.944.72.386.93 1.31 3.226 1.426 3.46.116.234.193.508.038.818-.155.31-.232.503-.464.775l-.696.815c-.232.23-.474.48-.204.94.27.46 1.2 1.98 2.576 3.206 1.77 1.578 3.263 2.066 3.723 2.298.46.232.73.194 1-.117.27-.31 1.15-1.343 1.458-1.804.31-.46.618-.386 1.043-.232.425.155 2.704 1.276 3.167 1.508.464.232.773.348.888.542.116.194.116 1.117-.27 2.206z" data-astro-cid-ju4pidww></path></svg><span class="fab-label" data-astro-cid-ju4pidww>WhatsApp</span></a><a class="fab fab-call" href="tel:+919310959596" aria-label="Call us now at +91 93109 59596" data-astro-cid-ju4pidww><svg class="fab-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" data-astro-cid-ju4pidww><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" data-astro-cid-ju4pidww></path></svg><span class="fab-label" data-astro-cid-ju4pidww>Call now</span></a></div><!-- Theme toggle + scroll reveal (progressive enhancement, ~20 lines) --><script>
      (function () {
        var btn = document.getElementById('theme-toggle');
        if (btn) btn.addEventListener('click', function () {
          var next = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
          document.documentElement.dataset.theme = next;
          try {
            localStorage.setItem('practest-theme', next);
            var host = location.hostname;
            var domain = host.endsWith('practest.live') ? ';domain=.practest.live' : '';
            document.cookie = 'practest_theme=' + next + ';path=/;max-age=31536000;SameSite=Lax' + domain;
          } catch (e) { /* still applied for this page */ }
        });

        if ('IntersectionObserver' in window) {
          var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
              if (en.isIntersecting) { en.target.classList.add('in-view'); io.unobserve(en.target); }
            });
          }, { threshold: 0.12 });
          document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });
        } else {
          document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('in-view'); });
        }
      })();
    <\/script></body></html>`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/layouts/Layout.astro", void 0);
//#endregion
export { createComponent as n, __exportAll as r, $$Layout as t };
