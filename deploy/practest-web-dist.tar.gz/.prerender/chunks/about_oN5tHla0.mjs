import { n as createComponent, r as __exportAll, t as $$Layout } from "./Layout_DzppV3bk.mjs";
import { h as addAttribute, l as renderTemplate, p as maybeRenderHead, r as renderComponent } from "./server_BmHvQwWi.mjs";
//#region src/pages/about.astro
var about_exports = /* @__PURE__ */ __exportAll({
	default: () => $$About,
	file: () => $$file,
	url: () => $$url
});
var $$About = createComponent(($$result, $$props, $$slots) => {
	const spaUrl = "https://app.practest.live";
	const pillars = [
		{
			n: "01",
			h: "Exact exam interface",
			p: "Five-state question palette, marked-for-review tags and section switching engineered to match official vendor CBT software."
		},
		{
			n: "02",
			h: "Percentile analytics",
			p: "Instant rank and percentile computed across every batch test-taker, with subject and topic-wise breakdowns."
		},
		{
			n: "03",
			h: "Structured video courses",
			p: "Curated LMS modules with lessons in exam order and automatic per-student progress tracking."
		},
		{
			n: "04",
			h: "Offline + online access",
			p: "Seamless batch activation via institute codes and receipt verification, or online payment when enrolment is open."
		}
	];
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": "About e-Learning Practest — A Vinstitution Brand",
		"description": "e-Learning Practest is the exam-prep platform of Vinstitution, a segment of VPD Vastus Ventures Private Limited, founded by educator Mr. Virat Priyadarshan.",
		"data-astro-cid-ta2fbyqs": true
	}, { "default": ($$result2) => renderTemplate`${maybeRenderHead($$result2)}<div class="about" data-astro-cid-ta2fbyqs><!-- Hero --><section class="a-hero" data-astro-cid-ta2fbyqs><span class="section-label" data-astro-cid-ta2fbyqs><span class="idx" data-astro-cid-ta2fbyqs>✳</span> About us</span><h1 data-astro-cid-ta2fbyqs>Exam-accurate practice, built by <span class="marker-underline" data-astro-cid-ta2fbyqs>educators</span>.</h1><p class="a-sub" data-astro-cid-ta2fbyqs><strong data-astro-cid-ta2fbyqs>e-Learning Practest<sup class="r" data-astro-cid-ta2fbyqs>®</sup></strong> is the flagship computer-based-test platform of <strong data-astro-cid-ta2fbyqs>Vinstitution</strong> — created to give every serious Indian competitive-exam aspirant the exact environment they'll face on exam day, months before they walk into the hall.</p></section><!-- Founder --><section class="founder reveal" data-astro-cid-ta2fbyqs><div class="founder-card glass-panel" data-astro-cid-ta2fbyqs><div class="founder-badge" data-astro-cid-ta2fbyqs>FOUNDER'S NOTE</div><blockquote data-astro-cid-ta2fbyqs>“Aspirants don't lose marks because they don't know the syllabus — they lose them to an unfamiliar interface, a mis-managed clock and untested exam temperament. We built e-Learning Practest so that the mock feels indistinguishable from the real thing, and the analytics tell you the truth about where you stand.”</blockquote><div class="founder-by" data-astro-cid-ta2fbyqs><span class="founder-avatar" aria-hidden="true" data-astro-cid-ta2fbyqs>VP</span><span data-astro-cid-ta2fbyqs><b data-astro-cid-ta2fbyqs>Mr. Virat Priyadarshan</b><em data-astro-cid-ta2fbyqs>Founder — Vinstitution · Visionary educator</em></span></div></div></section><!-- Mission / Why --><section class="cols reveal" data-astro-cid-ta2fbyqs><div class="col glass-panel" data-astro-cid-ta2fbyqs><span class="col-label" data-astro-cid-ta2fbyqs>Our mission</span><h2 data-astro-cid-ta2fbyqs>Make real-exam practice accessible to every aspirant.</h2><p data-astro-cid-ta2fbyqs>We replicate exact CBT interface standards — SSC CGL, SBI PO, IBPS, RRB NTPC and more — with server-authoritative sectional timers, KaTeX-rendered quantitative questions, instant autosave and rigorous post-test percentile analysis, so confidence is built on evidence, not hope.</p></div><div class="col glass-panel" data-astro-cid-ta2fbyqs><span class="col-label" data-astro-cid-ta2fbyqs>Why e-Learning Practest</span><h2 data-astro-cid-ta2fbyqs>Test-engine fidelity, not a generic LMS.</h2><p data-astro-cid-ta2fbyqs>Unlike generic learning apps, every submission is re-scored on the server from raw answers — never a client-side estimate. The timer is authoritative, autosave is relentless, and a dropped connection never costs you an attempt. It behaves like the vendor software because that is the whole point.</p></div></section><!-- Pillars --><section class="pillars reveal" data-astro-cid-ta2fbyqs><span class="section-label" data-astro-cid-ta2fbyqs><span class="idx" data-astro-cid-ta2fbyqs>01</span> What we stand for</span><h2 class="sec-h" data-astro-cid-ta2fbyqs>Built for Indian one-day &amp; civil-service exams.</h2><div class="pillar-grid" data-astro-cid-ta2fbyqs>${pillars.map((x) => renderTemplate`<div class="pillar glass-panel glass-panel-hover" data-astro-cid-ta2fbyqs><span class="pillar-n" data-astro-cid-ta2fbyqs>${x.n}</span><h3 data-astro-cid-ta2fbyqs>${x.h}</h3><p data-astro-cid-ta2fbyqs>${x.p}</p></div>`)}</div></section><!-- Corporate --><section class="corp reveal" data-astro-cid-ta2fbyqs><span class="section-label" data-astro-cid-ta2fbyqs><span class="idx" data-astro-cid-ta2fbyqs>02</span> The company behind it</span><h2 class="sec-h" data-astro-cid-ta2fbyqs>Structure &amp; credentials.</h2><div class="corp-flow" data-astro-cid-ta2fbyqs><div class="corp-node glass-panel" data-astro-cid-ta2fbyqs><span class="corp-tag" data-astro-cid-ta2fbyqs>PARENT COMPANY</span><b data-astro-cid-ta2fbyqs>VPD Vastus Ventures Private Limited</b><em data-astro-cid-ta2fbyqs>Incorporated entity</em></div><span class="corp-arrow" aria-hidden="true" data-astro-cid-ta2fbyqs>→</span><div class="corp-node glass-panel" data-astro-cid-ta2fbyqs><span class="corp-tag" data-astro-cid-ta2fbyqs>SEGMENT</span><b data-astro-cid-ta2fbyqs>Vinstitution</b><em data-astro-cid-ta2fbyqs>Education division</em></div><span class="corp-arrow" aria-hidden="true" data-astro-cid-ta2fbyqs>→</span><div class="corp-node glass-panel accent" data-astro-cid-ta2fbyqs><span class="corp-tag" data-astro-cid-ta2fbyqs>BRAND / PRODUCT</span><b data-astro-cid-ta2fbyqs>e-Learning Practest<sup class="r" data-astro-cid-ta2fbyqs>®</sup></b><em data-astro-cid-ta2fbyqs>CBT test-series platform</em></div></div><div class="corp-creds glass-panel" data-astro-cid-ta2fbyqs><div data-astro-cid-ta2fbyqs><span data-astro-cid-ta2fbyqs>PAN</span><b data-astro-cid-ta2fbyqs>AAMCV2938B</b></div><div data-astro-cid-ta2fbyqs><span data-astro-cid-ta2fbyqs>GSTIN</span><b data-astro-cid-ta2fbyqs>07AAMCV2938B1ZA</b></div><div data-astro-cid-ta2fbyqs><span data-astro-cid-ta2fbyqs>Quality</span><b data-astro-cid-ta2fbyqs>ISO 9001:2015 Certified</b></div></div></section><!-- CTA --><section class="a-cta reveal" data-astro-cid-ta2fbyqs><div class="a-cta-band glass-panel" data-astro-cid-ta2fbyqs><div data-astro-cid-ta2fbyqs><h2 data-astro-cid-ta2fbyqs>Ready to practise like it's the real exam?</h2><p data-astro-cid-ta2fbyqs>Explore our active batches, or jump straight into the test-engine portal.</p></div><div class="a-cta-actions" data-astro-cid-ta2fbyqs><a href="/courses" class="btn-primary" data-astro-cid-ta2fbyqs>Browse courses</a><a${addAttribute(`${spaUrl}/login`, "href")} class="btn-secondary" data-astro-cid-ta2fbyqs>Student portal →</a></div></div></section></div>` })}`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/about.astro", void 0);
var $$file = "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/about.astro";
var $$url = "/about";
//#endregion
//#region \0virtual:astro:page:src/pages/about@_@astro
var page = () => about_exports;
//#endregion
export { page };
