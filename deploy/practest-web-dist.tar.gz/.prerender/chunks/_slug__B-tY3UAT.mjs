import { n as createComponent, r as __exportAll, t as $$Layout } from "./Layout_DzppV3bk.mjs";
import { S as createAstro, b as unescapeHTML, g as defineScriptVars, h as addAttribute, l as renderTemplate, p as maybeRenderHead, r as renderComponent } from "./server_BmHvQwWi.mjs";
//#region src/pages/courses/[slug].astro
var _slug__exports = /* @__PURE__ */ __exportAll({
	default: () => $$Slug,
	file: () => $$file,
	getStaticPaths: () => getStaticPaths,
	url: () => $$url
});
createAstro("https://www.practest.live");
async function getStaticPaths() {
	console.log("--- GETSTATICPATHS EXECUTION START ---");
	try {
		const apiUrl = "https://api.practest.live";
		console.log("apiUrl is: https://api.practest.live");
		const res = await fetch(`${apiUrl}/api/courses/public`);
		if (res.ok) {
			const courses = await res.json();
			console.log("Fetched courses: " + courses.length);
			if (courses.length > 0) return courses.map((course) => ({
				params: { slug: course.slug },
				props: { course }
			}));
		}
	} catch (e) {
		console.warn("Could not fetch public courses at build time. Generating fallback path.", e.message);
	}
	console.log("Returning fallback math-special route");
	return [{
		params: { slug: "math-special" },
		props: { course: null }
	}];
}
var $$Slug = createComponent(async ($$result, $$props, $$slots) => {
	const Astro2 = $$result.createAstro($$props, $$slots);
	Astro2.self = $$Slug;
	const { slug } = Astro2.params;
	const { course } = Astro2.props;
	const spaUrl = "https://app.practest.live";
	const apiUrl = "https://api.practest.live";
	const bannerStyle = course?.banner_url ? `background-image: linear-gradient(135deg, rgba(11, 15, 25, 0.95) 0%, rgba(17, 24, 39, 0.8) 100%), url(${course.banner_url}); background-size: cover; background-position: center;` : `background-image: linear-gradient(135deg, rgba(11, 15, 25, 0.95) 0%, rgba(99, 102, 241, 0.08) 100%), url('/images/course-placeholder.svg'); background-size: cover; background-position: center;`;
	const courseSchema = course ? JSON.stringify({
		"@context": "https://schema.org",
		"@type": "Course",
		"name": course.title,
		"description": course.short_description || course.description,
		"provider": {
			"@type": "Organization",
			"name": "Practest",
			"sameAs": "https://www.practest.live"
		}
	}) : null;
	const faqSchema = course?.faq && Array.isArray(course.faq) && course.faq.length > 0 ? JSON.stringify({
		"@context": "https://schema.org",
		"@type": "FAQPage",
		"mainEntity": course.faq.map((f) => ({
			"@type": "Question",
			"name": f.question || f.q,
			"acceptedAnswer": {
				"@type": "Answer",
				"text": f.answer || f.a
			}
		}))
	}) : null;
	return renderTemplate`${renderComponent($$result, "Layout", $$Layout, {
		"title": course ? `${course.title} - Practest Courses` : "Course Details - Practest",
		"description": course ? course.short_description || course.description : "View mock tests, video syllabus and pricing.",
		"data-astro-cid-hmwiulc6": true
	}, { "default": ($$result2) => renderTemplate`${courseSchema && renderTemplate`<script type="application/ld+json">${unescapeHTML(courseSchema)}<\/script>`}${faqSchema && renderTemplate`<script type="application/ld+json">${unescapeHTML(faqSchema)}<\/script>`}${maybeRenderHead($$result2)}<div class="details-page-container" data-astro-cid-hmwiulc6><!-- Header Hero banner --><div id="course-banner-bg" class="course-header-banner glass-panel"${addAttribute(bannerStyle, "style")} data-astro-cid-hmwiulc6><div id="course-category" class="category-badge" data-astro-cid-hmwiulc6>${course?.exam_category || "General"}</div><h1 id="course-title" data-astro-cid-hmwiulc6>${course?.title || "Loading Course Details..."}</h1><p id="course-desc" data-astro-cid-hmwiulc6>${course?.short_description || course?.description || "Retrieving latest pricing and schedules..."}</p><div class="banner-meta" data-astro-cid-hmwiulc6><span id="course-mode" data-astro-cid-hmwiulc6>💻 Mode: ${course?.mode || "online"}</span></div></div><!-- Main Details Grid --><div class="details-grid" data-astro-cid-hmwiulc6><!-- Left side: Syllabus Outline & FAQ --><div class="content-left" data-astro-cid-hmwiulc6><!-- Syllabus Accordion --><div class="glass-panel info-section" data-astro-cid-hmwiulc6><h3 data-astro-cid-hmwiulc6>📚 Syllabus & Curriculum</h3><div id="syllabus-container" class="syllabus-list" data-astro-cid-hmwiulc6>${course?.syllabus && Array.isArray(course.syllabus) ? course.syllabus.map((s, idx) => renderTemplate`<div class="syllabus-item" data-astro-cid-hmwiulc6><div class="item-number" data-astro-cid-hmwiulc6>${idx + 1}</div><div class="item-title" data-astro-cid-hmwiulc6>${s}</div></div>`) : renderTemplate`<p class="empty-notice" data-astro-cid-hmwiulc6>Syllabus outline will be loaded dynamically.</p>`}</div></div><!-- FAQs --><div class="glass-panel info-section" style="margin-top: 30px;" data-astro-cid-hmwiulc6><h3 data-astro-cid-hmwiulc6>🙋 Frequently Asked Questions</h3><div id="faq-container" class="faq-list" data-astro-cid-hmwiulc6>${course?.faq && Array.isArray(course.faq) ? course.faq.map((f) => renderTemplate`<div class="faq-item" data-astro-cid-hmwiulc6><div class="faq-q" data-astro-cid-hmwiulc6>❓ ${f.question || f.q}</div><div class="faq-a" data-astro-cid-hmwiulc6>${f.answer || f.a}</div></div>`) : renderTemplate`<p class="empty-notice" data-astro-cid-hmwiulc6>FAQ topics will be loaded dynamically.</p>`}</div></div></div><!-- Right side: Batch Purchase widget --><div class="content-right" data-astro-cid-hmwiulc6><div class="glass-panel purchase-card" data-astro-cid-hmwiulc6><h3 data-astro-cid-hmwiulc6>💰 Available Batches</h3><div id="batches-loading" class="batches-loading" data-astro-cid-hmwiulc6><div class="mini-spinner" data-astro-cid-hmwiulc6></div><span data-astro-cid-hmwiulc6>Checking live batch availability...</span></div><div id="batches-container" class="batches-list" style="display: none;" data-astro-cid-hmwiulc6><!-- Hydrated by JS --></div><div id="no-batches-state" class="no-batches-state" style="display: none;" data-astro-cid-hmwiulc6><p data-astro-cid-hmwiulc6>No priced batches currently open for online enrollment.</p><a href="/contact" class="btn-secondary" style="width: 100%; text-align: center;" data-astro-cid-hmwiulc6>Contact Admin to Join</a></div></div></div></div></div>` })}<script>(function(){${defineScriptVars({
		apiUrl,
		spaUrl,
		slug,
		initialCourse: course
	})}
  // Escapes strings for HTML injection
  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // Renders batches dynamically in the DOM
  function renderBatches(batches) {
    const loading = document.getElementById('batches-loading');
    const container = document.getElementById('batches-container');
    const noBatches = document.getElementById('no-batches-state');

    loading.style.display = 'none';

    if (!batches || batches.length === 0) {
      container.style.display = 'none';
      noBatches.style.display = 'block';
      return;
    }

    container.innerHTML = batches.map(batch => {
      const price = batch.price_paise ? (batch.price_paise / 100).toLocaleString() : '0';
      const startDate = batch.starts_at ? new Date(batch.starts_at).toLocaleDateString() : 'Immediate';
      
      return \`
        <div class="batch-card">
          <div class="batch-header">
            <h4>\${escapeHtml(batch.name)}</h4>
            <span class="batch-price">₹\${price}</span>
          </div>
          <p class="batch-dates">📅 Starts: \${startDate}</p>
          <a href="\${spaUrl}/login?enroll_batch=\${batch.id}" class="btn-primary buy-btn">
            Register & Enroll
          </a>
        </div>
      \`;
    }).join('');

    noBatches.style.display = 'none';
    container.style.display = 'flex';
  }

  // Hydrate full course details and live batches
  async function hydrateCourse() {
    try {
      const res = await fetch(\`\${apiUrl}/api/courses/public\`);
      if (!res.ok) throw new Error('Failed to fetch courses catalog');
      const courses = await res.json();
      
      const currentCourse = courses.find(c => c.slug === slug);
      if (!currentCourse) {
        document.getElementById('batches-loading').style.display = 'none';
        document.getElementById('no-batches-state').style.display = 'block';
        return;
      }

      // Update basic fields in case static generation was empty/fallback
      document.getElementById('course-title').textContent = currentCourse.title;
      document.getElementById('course-desc').textContent = currentCourse.short_description || currentCourse.description || '';
      document.getElementById('course-category').textContent = currentCourse.exam_category || 'General';
      document.getElementById('course-mode').textContent = \`💻 Mode: \${currentCourse.mode || 'online'}\`;

      // Update background image
      const bannerBg = document.getElementById('course-banner-bg');
      if (bannerBg) {
        const bannerUrl = currentCourse.banner_url || '/images/course-placeholder.svg';
        bannerBg.style.backgroundImage = \`linear-gradient(135deg, rgba(11, 15, 25, 0.95) 0%, rgba(17, 24, 39, 0.8) 100%), url(\${bannerUrl})\`;
        bannerBg.style.backgroundSize = 'cover';
        bannerBg.style.backgroundPosition = 'center';
      }

      // Update Syllabus list if fallback empty
      const syllabusList = document.getElementById('syllabus-container');
      if (currentCourse.syllabus && Array.isArray(currentCourse.syllabus) && currentCourse.syllabus.length > 0) {
        syllabusList.innerHTML = currentCourse.syllabus.map((s, idx) => \`
          <div class="syllabus-item">
            <div class="item-number">\${idx + 1}</div>
            <div class="item-title">\${escapeHtml(s)}</div>
          </div>
        \`).join('');
      }

      // Update FAQ list if fallback empty
      const faqList = document.getElementById('faq-container');
      if (currentCourse.faq && Array.isArray(currentCourse.faq) && currentCourse.faq.length > 0) {
        faqList.innerHTML = currentCourse.faq.map(f => \`
          <div class="faq-item">
            <div class="faq-q">❓ \${escapeHtml(f.question || f.q || '')}</div>
            <div class="faq-a">\${escapeHtml(f.answer || f.a || '')}</div>
          </div>
        \`).join('');
      }

      // Render Batches
      renderBatches(currentCourse.batches);

      // Push ViewContent event to GTM dataLayer
      window.dataLayer = window.dataLayer || [];
      const activePrices = (currentCourse.batches || []).map(b => b.price_paise).filter(p => p !== null && p !== undefined);
      const minPrice = activePrices.length > 0 ? Math.min(...activePrices) / 100 : 0;
      window.dataLayer.push({
        event: 'ViewContent',
        content_name: currentCourse.title,
        content_category: currentCourse.exam_category || 'General',
        content_ids: [currentCourse.id],
        content_type: 'product',
        value: minPrice,
        currency: 'INR'
      });

    } catch (e) {
      console.error('Failed to hydrate course details', e);
      document.getElementById('batches-loading').style.display = 'none';
      
      // If we had static values, fall back to rendering them
      if (initialCourse && initialCourse.batches) {
        renderBatches(initialCourse.batches);

        // Push fallback ViewContent event to GTM dataLayer
        window.dataLayer = window.dataLayer || [];
        const staticPrices = (initialCourse.batches || []).map(b => b.price_paise).filter(p => p !== null && p !== undefined);
        const minStaticPrice = staticPrices.length > 0 ? Math.min(...staticPrices) / 100 : 0;
        window.dataLayer.push({
          event: 'ViewContent',
          content_name: initialCourse.title,
          content_category: initialCourse.exam_category || 'General',
          content_ids: [initialCourse.id],
          content_type: 'product',
          value: minStaticPrice,
          currency: 'INR'
        });
      } else {
        document.getElementById('no-batches-state').style.display = 'block';
      }
    }
  }

  // Load course details
  hydrateCourse();
})();<\/script>`;
}, "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/courses/[slug].astro", void 0);
var $$file = "C:/Users/thevi/Downloads/e-Learning_Practest/web/src/pages/courses/[slug].astro";
var $$url = "/courses/[slug]";
//#endregion
//#region \0virtual:astro:page:src/pages/courses/[slug]@_@astro
var page = () => _slug__exports;
//#endregion
export { page };
